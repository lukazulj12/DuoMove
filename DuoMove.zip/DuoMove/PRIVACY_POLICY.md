# Pravila privatnosti – DuoMove

*Vrijedi od: 1. 11. 2026.*

DuoMove pronalazi i uklanja duplicirane datoteke, ispravlja datume fotografija i videozapisa prema njihovim nazivima
te prenosi datoteke između dva korisnikova mobitela.

**Podaci koje developer prikuplja: nikakvi.**

- Aplikacija nema registraciju, oglase, analitiku ni alate trećih strana za praćenje i ne šalje podatke developeru ni bilo kojem poslužitelju.
- Sva obrada (usporedba datoteka, prepoznavanje datuma) odvija se **lokalno na uređaju**.
- **Prijenos između mobitela:** datoteke koje korisnik odabere šalju se izravno s jednog njegovog mobitela na drugi
  (izravna Wi-Fi veza ili lokalna Wi-Fi mreža), bez interneta i bez posrednika. Veza je zaštićena lozinkom i kodom koji se prikazuje
  samo na mobitelu primatelju. Dopuštenje za internet koristi se isključivo za tu lokalnu vezu.
- Rezultati skeniranja i postavke spremaju se samo u privatnu pohranu aplikacije i brišu se deinstalacijom.
- Datoteke se brišu ili mijenjaju (datumi) **samo** nakon izričite potvrde korisnika.

**Dopuštenja:** pristup fotografijama, videozapisima i audiozapisima (pronalaženje duplikata, ispravak datuma, slanje);
pristup lokaciji u medijima (usporedba i prijenos izvornih datoteka – lokacija se ne čita i ne prikazuje); Wi-Fi uređaji u blizini
(Android 13+) odnosno lokacija (Android 11–12) – samo za izravnu Wi-Fi vezu, lokacija se ne koristi; obavijesti i rad u pozadini
(napredak skeniranja i prijenosa); popis instaliranih aplikacija s ikonom (samo ako korisnik odabere prijenos aplikacija).

**Kontakt:** lukafrane.zulj@gmail.com

---

# Privacy Policy – DuoMove

*Effective: 1 November 2026.*

DuoMove finds and removes duplicate files, fixes photo and video dates based on their file names, and transfers files between
two of the user's phones.

**Data collected by the developer: none.**

- No accounts, ads, analytics or third-party tracking. No data is sent to the developer or to any server.
- All processing (file comparison, date recognition) happens **locally on the device**.
- **Phone-to-phone transfer:** files chosen by the user are sent directly from one of the user's phones to the other (Wi-Fi Direct or the
  local Wi-Fi network), without the internet or any intermediary. The connection is protected by a password and a code shown only on the
  receiving phone. The internet permission is used only for this local connection.
- Scan results and settings are stored only in the app's private storage and are removed when the app is uninstalled.
- Files are deleted or modified (dates) **only** after the user's explicit confirmation.

**Permissions:** photos, videos and audio (finding duplicates, fixing dates, sending); media location (comparing and transferring original
files – location is never read or shown); nearby Wi-Fi devices (Android 13+) or location (Android 11–12) – only for the direct Wi-Fi
connection, location is not used; notifications and background work (scan and transfer progress); list of installed launchable apps
(only if the user chooses to transfer apps).

**Contact:** lukafrane.zulj@gmail.com
