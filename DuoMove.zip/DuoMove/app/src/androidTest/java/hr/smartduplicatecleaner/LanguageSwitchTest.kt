package hr.smartduplicatecleaner

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.core.os.LocaleListCompat
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Scenarij 13: promjena jezika unutar aplikacije i ponovno stvaranje aktivnosti.
 * Pokretanje na uređaju/emulatoru: ./gradlew :app:connectedDebugAndroidTest
 */
@RunWith(AndroidJUnit4::class)
class LanguageSwitchTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private fun setLocale(tag: String) {
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        }
        rule.activityRule.scenario.recreate()
        rule.waitForIdle()
    }

    @Test
    fun switchCroatianEnglishAndRecreate() {
        setLocale("hr")
        rule.onNodeWithText("Skeniraj datoteke").assertExists()
        setLocale("en")
        rule.onNodeWithText("Scan files").assertExists()
        // Nakon ponovnog stvaranja jezik ostaje odabran.
        rule.activityRule.scenario.recreate()
        rule.onNodeWithText("Scan files").assertExists()
    }

    @After
    fun reset() {
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.getEmptyLocaleList())
        }
    }
}
