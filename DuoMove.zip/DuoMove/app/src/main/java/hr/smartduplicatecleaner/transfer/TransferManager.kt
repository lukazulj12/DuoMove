package hr.smartduplicatecleaner.transfer

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.core.transfer.PairingCode
import hr.smartduplicatecleaner.core.transfer.TransferException
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.core.transfer.TransferProgress
import hr.smartduplicatecleaner.core.transfer.TransferReceiver
import hr.smartduplicatecleaner.core.transfer.TransferResult
import hr.smartduplicatecleaner.core.transfer.TransferSender
import hr.smartduplicatecleaner.data.settings.FeatureSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

enum class TransferRole { SEND, RECEIVE }

enum class TransferFailure {
    NO_PERMISSION, WIFI_OFF, LOCATION_OFF, P2P_UNSUPPORTED, P2P_FAILED, NOT_FOUND,
    CONNECT_FAILED, AUTH_FAILED, BUSY, NO_SPACE, PORT_IN_USE, NO_NETWORK, UNKNOWN
}

sealed class TransferState {
    data object Idle : TransferState()
    data class Preparing(val role: TransferRole) : TransferState()
    /** Primatelj čeka pošiljatelja. [address] je prikazan samo u načinu "ista mreža". */
    data class Waiting(val code: String, val direct: Boolean, val address: String?) : TransferState()
    data class Active(val role: TransferRole, val progress: TransferProgress, val peer: String) : TransferState()
    data class Finished(val role: TransferRole, val result: TransferResult, val apps: List<ReceivedApp>) : TransferState()
    data class Failed(val role: TransferRole, val reason: TransferFailure, val freeBytes: Long = -1) : TransferState()

    val isBusy: Boolean get() = this is Preparing || this is Waiting || this is Active
}

/**
 * Upravlja prijenosom u opsegu aplikacije (nastavlja raditi kad korisnik napusti zaslon).
 * Uz uključen rad u pozadini pokreće [TransferService] (obavijest + wake lock + Wi-Fi lock).
 */
class TransferManager(private val context: Context, private val features: FeatureSettingsRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<TransferState>(TransferState.Idle)
    val state: StateFlow<TransferState> = _state.asStateFlow()

    private var job: Job? = null
    private var receiver: TransferReceiver? = null
    private var sink: AndroidTransferSink? = null
    private var p2p: P2pLink? = null
    private val cancelled = AtomicBoolean(false)

    /** Provjere prije Wi-Fi Direct veze; null = sve u redu. */
    fun precheck(direct: Boolean): TransferFailure? {
        if (!P2pLink.isWifiEnabled(context)) return TransferFailure.WIFI_OFF
        if (!direct) return null
        if (!P2pLink(context).isSupported) return TransferFailure.P2P_UNSUPPORTED
        if (!P2pLink.hasPermissions(context)) return TransferFailure.NO_PERMISSION
        if (!P2pLink.isLocationOk(context)) return TransferFailure.LOCATION_OFF
        return null
    }

    // ---------- Primanje ----------

    fun startReceiving() {
        if (_state.value.isBusy) return
        cancelled.set(false)
        _state.value = TransferState.Preparing(TransferRole.RECEIVE)
        job = scope.launch {
            val prefs = features.currentTransfer()
            if (prefs.background) startService()
            precheck(prefs.directMode)?.let { fail(TransferRole.RECEIVE, it); return@launch }
            val code = PairingCode.generate()
            var address: String? = null
            if (prefs.directMode) {
                val link = P2pLink(context).also { p2p = it }
                try {
                    link.createGroup(code)
                } catch (e: Exception) {
                    fail(TransferRole.RECEIVE, TransferFailure.P2P_FAILED); return@launch
                }
            } else {
                address = P2pLink.localIpv4(context)
                if (address == null) { fail(TransferRole.RECEIVE, TransferFailure.NO_NETWORK); return@launch }
            }
            val s = AndroidTransferSink(context, prefs.skipExisting).also { sink = it }
            var peer = ""
            val r = TransferReceiver(code, s, object : TransferReceiver.Listener {
                override fun onSessionStarted(deviceName: String, files: Int, bytes: Long) {
                    peer = deviceName
                    _state.value = TransferState.Active(TransferRole.RECEIVE, TransferProgress(0, files, 0, bytes, 0, System.currentTimeMillis()), deviceName)
                }
                override fun onProgress(progress: TransferProgress) {
                    _state.value = TransferState.Active(TransferRole.RECEIVE, progress, peer)
                }
                override fun onSessionFinished(result: TransferResult) {
                    _state.value = TransferState.Finished(TransferRole.RECEIVE, result, s.receivedApps())
                    stopReceiverInternal()
                }
                override fun onRejectedNoSpace(needed: Long, free: Long) {
                    _state.value = TransferState.Failed(TransferRole.RECEIVE, TransferFailure.NO_SPACE, free)
                    stopReceiverInternal()
                }
            })
            try {
                r.start()
                receiver = r
                _state.value = TransferState.Waiting(code, prefs.directMode, address)
            } catch (e: Exception) {
                fail(TransferRole.RECEIVE, TransferFailure.PORT_IN_USE)
            }
        }
    }

    private fun stopReceiverInternal() {
        receiver?.stop(); receiver = null
        p2p?.close(); p2p = null
    }

    // ---------- Slanje ----------

    fun startSending(items: List<TransferItem>, codeInput: String, host: String?) {
        if (_state.value.isBusy) return
        val code = PairingCode.normalize(codeInput) ?: run { _state.value = TransferState.Failed(TransferRole.SEND, TransferFailure.AUTH_FAILED); return }
        cancelled.set(false)
        _state.value = TransferState.Preparing(TransferRole.SEND)
        job = scope.launch {
            val prefs = features.currentTransfer()
            if (prefs.background) startService()
            precheck(prefs.directMode)?.let { fail(TransferRole.SEND, it); return@launch }
            val address = if (prefs.directMode) {
                val link = P2pLink(context).also { p2p = it }
                try {
                    link.join(code)
                } catch (e: TimeoutCancellationException) {
                    fail(TransferRole.SEND, TransferFailure.NOT_FOUND); return@launch
                } catch (e: Exception) {
                    fail(TransferRole.SEND, TransferFailure.P2P_FAILED); return@launch
                }
            } else {
                host?.trim()?.takeIf { it.isNotEmpty() } ?: run { fail(TransferRole.SEND, TransferFailure.CONNECT_FAILED); return@launch }
            }
            val name = (Build.MANUFACTURER + " " + Build.MODEL).trim()
            // Nakon pridruživanja mreži IP adresa ponekad kasni – nekoliko pokušaja spajanja.
            var lastError: TransferException? = null
            for (attempt in 0 until 5) {
                if (cancelled.get()) break
                try {
                    val sender = TransferSender(address, PairingCode.PORT, code, deviceName = name, streams = STREAMS)
                    val result = sender.send(items, AndroidTransferSource(context), { cancelled.get() }) { p ->
                        _state.value = TransferState.Active(TransferRole.SEND, p, address)
                    }
                    _state.value = TransferState.Finished(TransferRole.SEND, result, emptyList())
                    p2p?.close(); p2p = null
                    return@launch
                } catch (e: TransferException) {
                    lastError = e
                    if (e.reason != TransferException.Reason.CONNECTION || _state.value is TransferState.Active) break
                    delay(1500)
                }
            }
            p2p?.close(); p2p = null
            val reason = when (lastError?.reason) {
                TransferException.Reason.AUTH_FAILED -> TransferFailure.AUTH_FAILED
                TransferException.Reason.NO_SPACE -> TransferFailure.NO_SPACE
                TransferException.Reason.BUSY -> TransferFailure.BUSY
                null -> TransferFailure.UNKNOWN
                else -> TransferFailure.CONNECT_FAILED
            }
            if (cancelled.get()) _state.value = TransferState.Idle
            else _state.value = TransferState.Failed(TransferRole.SEND, reason, lastError?.freeBytes ?: -1)
        }
    }

    // ---------- Zajedničko ----------

    private fun fail(role: TransferRole, reason: TransferFailure) {
        stopReceiverInternal()
        _state.value = TransferState.Failed(role, reason)
    }

    /** Otkazivanje (pošiljatelj prekida slanje, primatelj prestaje čekati/primati). */
    fun cancel() {
        cancelled.set(true)
        val s = _state.value
        if (s is TransferState.Waiting || s is TransferState.Preparing || (s is TransferState.Active && s.role == TransferRole.RECEIVE)) {
            job?.cancel()
            stopReceiverInternal()
            _state.value = TransferState.Idle
        }
    }

    /** Povratak na početni zaslon nakon završetka ili pogreške. */
    fun reset() {
        if (_state.value.isBusy) return
        stopReceiverInternal()
        _state.value = TransferState.Idle
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java))
        } catch (e: Exception) {
            // Npr. ograničenje pokretanja usluga – prijenos radi dok je aplikacija otvorena.
        }
    }

    companion object {
        /** Broj paralelnih TCP veza – 4 daju najbolji omjer brzine i opterećenja na Wi-Fi Direct vezi. */
        const val STREAMS = 4

        fun wifiSettingsIntent(): Intent =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)

        fun locationSettingsIntent(): Intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
    }
}
