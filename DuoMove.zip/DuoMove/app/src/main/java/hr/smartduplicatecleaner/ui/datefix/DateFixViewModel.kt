package hr.smartduplicatecleaner.ui.datefix

import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.core.dates.DateFixItem
import hr.smartduplicatecleaner.core.dates.DateFixPlanner
import hr.smartduplicatecleaner.core.dates.DateFixSettings
import hr.smartduplicatecleaner.core.dates.DateFixStatus
import hr.smartduplicatecleaner.core.dates.NameDateParser
import hr.smartduplicatecleaner.data.settings.DateFixPrefs
import hr.smartduplicatecleaner.datefix.DateFixMedia
import hr.smartduplicatecleaner.datefix.DateWriteResult
import hr.smartduplicatecleaner.datefix.DateWriter
import hr.smartduplicatecleaner.datefix.MediaFolder
import hr.smartduplicatecleaner.storage.StorageAccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.ZoneId

data class DateFixUi(
    val folders: List<MediaFolder>? = null,
    val analyzing: Boolean = false,
    val analyzed: Boolean = false,
    /** Datoteke čiji datum ne odgovara nazivu. */
    val toFix: List<DateFixItem> = emptyList(),
    val okCount: Int = 0,
    val noDateCount: Int = 0,
    val outOfIntervalCount: Int = 0,
    val selected: Set<String> = emptySet(),
    /** Ručno promijenjeni ciljni datumi po ključu datoteke. */
    val overrides: Map<String, Long> = emptyMap(),
    val running: Boolean = false,
    val progressDone: Int = 0,
    val progressTotal: Int = 0,
    val report: List<DateWriteResult>? = null,
    /** Sistemski dijalog za odobrenje izmjene (bez pristupa svim datotekama). */
    val writeRequest: IntentSender? = null
)

/** Ispravak datuma po nazivu: analiza, odabir, upis, izvještaj. */
class DateFixViewModel(private val c: AppContainer) : ViewModel() {
    private val writer = DateWriter(c.context)

    val prefs: StateFlow<DateFixPrefs> = c.features.dateFix.stateIn(viewModelScope, SharingStarted.Eagerly, DateFixPrefs())

    private val _ui = MutableStateFlow(DateFixUi())
    val ui: StateFlow<DateFixUi> = _ui.asStateFlow()

    private var pendingItems: List<DateFixItem> = emptyList()

    fun update(t: (DateFixPrefs) -> DateFixPrefs) {
        viewModelScope.launch { c.features.updateDateFix(t) }
    }

    fun loadFolders() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { DateFixMedia.folders(c.context) }
            _ui.update { it.copy(folders = list) }
        }
    }

    fun parser(p: DateFixPrefs = prefs.value) = NameDateParser(p.order, p.patterns, p.timestamps)

    fun analyze() {
        if (_ui.value.analyzing || _ui.value.running) return
        _ui.update { it.copy(analyzing = true, report = null) }
        viewModelScope.launch {
            val p = c.features.currentDateFix()
            val allFiles = StorageAccess.hasAllFilesAccess()
            val settings = DateFixSettings(
                from = if (p.intervalEnabled) p.from else null,
                to = if (p.intervalEnabled) p.to else null,
                basis = p.basis,
                checkTaken = p.writeMetadata,
                // Datum izmjene provjerava se samo ako ga je moguće i promijeniti.
                checkModified = p.writeModified && allFiles,
                compareTime = p.compareTime
            )
            val items = withContext(Dispatchers.Default) {
                val files = DateFixMedia.files(c.context, p.folders)
                DateFixPlanner.plan(files, parser(p), settings, ZoneId.systemDefault())
            }
            val toFix = items.filter { it.status == DateFixStatus.NEEDS_FIX }
                .sortedWith(compareBy({ it.file.relativeDir }, { it.file.name }))
            _ui.update {
                it.copy(
                    analyzing = false, analyzed = true, toFix = toFix,
                    okCount = items.count { i -> i.status == DateFixStatus.OK },
                    noDateCount = items.count { i -> i.status == DateFixStatus.NO_DATE_IN_NAME },
                    outOfIntervalCount = items.count { i -> i.status == DateFixStatus.OUT_OF_INTERVAL },
                    selected = toFix.map { i -> i.file.key }.toSet(),
                    overrides = emptyMap()
                )
            }
        }
    }

    fun toggle(key: String) = _ui.update { s ->
        s.copy(selected = if (key in s.selected) s.selected - key else s.selected + key)
    }

    fun selectAll(all: Boolean) = _ui.update { s -> s.copy(selected = if (all) s.toFix.map { it.file.key }.toSet() else emptySet()) }

    fun override(key: String, millis: Long) = _ui.update { s -> s.copy(overrides = s.overrides + (key to millis), selected = s.selected + key) }

    fun target(item: DateFixItem): Long? = _ui.value.overrides[item.file.key] ?: item.targetMillis

    /** Pokreće ispravak odabranih; bez pristupa svim datotekama najprije traži odobrenje sustava. */
    fun fixSelected() {
        val s = _ui.value
        if (s.running) return
        val items = s.toFix.filter { it.file.key in s.selected && target(it) != null }
        if (items.isEmpty()) return
        pendingItems = items
        val needRequest = items.filter { !writer.canWriteDirect(it.file) }.map { Uri.parse(it.file.uri) }
        if (needRequest.isNotEmpty()) {
            try {
                val pi = MediaStore.createWriteRequest(c.context.contentResolver, needRequest)
                _ui.update { it.copy(writeRequest = pi.intentSender) }
                return
            } catch (e: Exception) {
                // Nastavlja se – datoteke bez odobrenja bit će prijavljene kao neuspjele.
            }
        }
        run(items)
    }

    fun onWriteRequestResult() {
        _ui.update { it.copy(writeRequest = null) }
        run(pendingItems)
    }

    private fun run(items: List<DateFixItem>) {
        _ui.update { it.copy(running = true, progressDone = 0, progressTotal = items.size) }
        viewModelScope.launch {
            val p = c.features.currentDateFix()
            val results = withContext(Dispatchers.IO) {
                items.mapIndexed { i, item ->
                    val r = writer.write(item.file, target(item)!!, p.writeMetadata, p.writeModified)
                    _ui.update { it.copy(progressDone = i + 1) }
                    r
                }
            }
            val fixedKeys = results.filter { it.ok }.map { it.file.key }.toSet()
            _ui.update {
                it.copy(
                    running = false, report = results,
                    toFix = it.toFix.filter { i -> i.file.key !in fixedKeys },
                    selected = it.selected - fixedKeys
                )
            }
        }
    }

    fun closeReport() = _ui.update { it.copy(report = null) }
}
