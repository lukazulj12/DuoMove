package hr.smartduplicatecleaner.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import hr.smartduplicatecleaner.MainActivity
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.SdcApplication
import hr.smartduplicatecleaner.core.format.Formatters
import hr.smartduplicatecleaner.core.format.SizeUnit
import hr.smartduplicatecleaner.core.transfer.PairingCode
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Usluga u prvom planu za prijenos: obavijest s napretkom, djelomični wake lock (procesor radi i kad je
 * zaslon ugašen) i Wi-Fi lock visokih performansi (Wi-Fi ne prelazi u štedni način) – prijenos se ne
 * prekida kad se zaslon ugasi ili korisnik izađe na početni zaslon.
 */
class TransferService : LifecycleService() {
    private val manager get() = (application as SdcApplication).container.transferManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var lastUpdate = 0L

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.transfer_notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(this, ID, build(getString(R.string.transfer_title), null), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DuoMove:transfer")
            .apply { setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L) }
        @Suppress("DEPRECATION")
        wifiLock = applicationContext.getSystemService(WifiManager::class.java)
            ?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "DuoMove:transfer")
            ?.apply { setReferenceCounted(false); acquire() }
        lifecycleScope.launch {
            manager.state.collectLatest { s ->
                when (s) {
                    is TransferState.Preparing -> update(getString(R.string.transfer_preparing), null, force = true)
                    is TransferState.Waiting -> update(getString(R.string.transfer_notif_waiting, PairingCode.display(s.code)), null, force = true)
                    is TransferState.Active -> {
                        val p = s.progress
                        val percent = if (p.bytesTotal > 0) (p.bytesDone * 100 / p.bytesTotal).toInt() else 0
                        val speed = Formatters.size(p.bytesPerSecond(), SizeUnit.AUTO, Locale.getDefault()) + "/s"
                        val label = getString(if (s.role == TransferRole.SEND) R.string.transfer_sending else R.string.transfer_receiving)
                        update("$label · $percent % · $speed", percent, force = false)
                    }
                    else -> stopNow()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_CANCEL) manager.cancel()
        return START_NOT_STICKY
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopNow()
    }

    private fun update(text: String, percent: Int?, force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastUpdate < 1000) return
        lastUpdate = now
        getSystemService(NotificationManager::class.java).notify(ID, build(text, percent))
    }

    private fun build(text: String, percent: Int?) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_upload)
        .setContentTitle(getString(R.string.app_name))
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setProgress(100, percent ?: 0, percent == null)
        .setContentIntent(
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        )
        .addAction(0, getString(R.string.cancel), PendingIntent.getService(this, 1, Intent(this, TransferService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun stopNow() {
        release()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun release() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = null
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "transfer"
        private const val ID = 77
        private const val ACTION_CANCEL = "hr.smartduplicatecleaner.CANCEL_TRANSFER"
    }
}
