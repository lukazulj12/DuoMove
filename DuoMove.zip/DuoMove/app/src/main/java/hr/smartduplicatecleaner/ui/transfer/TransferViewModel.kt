package hr.smartduplicatecleaner.ui.transfer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.data.settings.TransferPrefs
import hr.smartduplicatecleaner.transfer.TransferScanner
import hr.smartduplicatecleaner.transfer.TransferState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Mapa u popisu za slanje. */
data class SendFolder(val dir: String, val count: Int, val bytes: Long, val categories: Set<TransferCategory>)

data class SendUi(
    /** true = otvoren zaslon za pripremu slanja. */
    val setup: Boolean = false,
    val scanning: Boolean = false,
    val items: List<TransferItem>? = null,
    val folders: List<SendFolder> = emptyList(),
    /** Mape koje korisnik NE želi poslati. */
    val excluded: Set<String> = emptySet(),
    val code: String = "",
    val host: String = ""
) {
    val selected: List<TransferItem> get() = items.orEmpty().filter { it.relativeDir !in excluded }
    val selectedBytes: Long get() = selected.sumOf { it.size }
}

class TransferViewModel(private val c: AppContainer) : ViewModel() {
    val prefs: StateFlow<TransferPrefs> = c.features.transfer.stateIn(viewModelScope, SharingStarted.Eagerly, TransferPrefs())
    val state: StateFlow<TransferState> = c.transferManager.state

    private val _send = MutableStateFlow(SendUi())
    val send: StateFlow<SendUi> = _send.asStateFlow()

    fun update(t: (TransferPrefs) -> TransferPrefs) {
        viewModelScope.launch { c.features.updateTransfer(t) }
    }

    fun openSendSetup() = _send.update { it.copy(setup = true) }
    fun closeSendSetup() = _send.update { SendUi() }

    fun scan() {
        if (_send.value.scanning) return
        _send.update { it.copy(scanning = true, items = null, excluded = emptySet()) }
        viewModelScope.launch {
            val p = c.features.currentTransfer()
            val safTrees = c.settings.current().safTrees
            val items = withContext(Dispatchers.IO) {
                TransferScanner.scan(
                    c.context, p.categories,
                    if (p.intervalEnabled) p.from else null,
                    if (p.intervalEnabled) p.to else null,
                    safTrees
                )
            }
            val folders = items.groupBy { it.relativeDir }.map { (dir, list) ->
                SendFolder(dir, list.size, list.sumOf { it.size }, list.map { it.category }.toSet())
            }.sortedWith(compareBy({ it.dir.lowercase() }))
            _send.update { it.copy(scanning = false, items = items, folders = folders) }
        }
    }

    fun toggleFolder(dir: String) = _send.update { s ->
        s.copy(excluded = if (dir in s.excluded) s.excluded - dir else s.excluded + dir)
    }

    fun setAllFolders(selected: Boolean) = _send.update { s ->
        s.copy(excluded = if (selected) emptySet() else s.folders.map { it.dir }.toSet())
    }

    fun setCode(v: String) = _send.update { it.copy(code = v.take(12)) }
    fun setHost(v: String) = _send.update { it.copy(host = v.take(40)) }

    fun startSending() {
        val s = _send.value
        // Novi slijedni ID-jevi za odabrane datoteke.
        val items = s.selected.mapIndexed { i, item -> item.copy(id = i) }
        if (items.isEmpty()) return
        c.transferManager.startSending(items, s.code, s.host)
    }

    fun startReceiving() = c.transferManager.startReceiving()
    fun cancel() = c.transferManager.cancel()
    fun reset() {
        c.transferManager.reset()
        _send.update { SendUi() }
    }
    fun precheck(direct: Boolean) = c.transferManager.precheck(direct)
}
