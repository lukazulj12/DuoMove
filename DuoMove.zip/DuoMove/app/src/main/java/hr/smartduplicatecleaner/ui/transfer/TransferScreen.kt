package hr.smartduplicatecleaner.ui.transfer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.transfer.PairingCode
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.storage.StorageAccess
import hr.smartduplicatecleaner.transfer.ApkInstaller
import hr.smartduplicatecleaner.transfer.P2pLink
import hr.smartduplicatecleaner.transfer.TransferFailure
import hr.smartduplicatecleaner.transfer.TransferManager
import hr.smartduplicatecleaner.transfer.TransferRole
import hr.smartduplicatecleaner.transfer.TransferState
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.IntervalPicker
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.RadioLine
import hr.smartduplicatecleaner.ui.components.SectionTitle
import hr.smartduplicatecleaner.ui.components.formatSize

@Composable
fun categoryName(c: TransferCategory): String = stringResource(
    when (c) {
        TransferCategory.PHOTOS -> R.string.tr_cat_photos
        TransferCategory.VIDEOS -> R.string.tr_cat_videos
        TransferCategory.AUDIO -> R.string.tr_cat_audio
        TransferCategory.DOCUMENTS -> R.string.tr_cat_documents
        TransferCategory.ARCHIVES -> R.string.tr_cat_archives
        TransferCategory.APK_FILES -> R.string.tr_cat_apk
        TransferCategory.APPS -> R.string.tr_cat_apps
        TransferCategory.OTHER -> R.string.tr_cat_other
    }
)

private fun missing(context: Context, perms: Array<String>) =
    perms.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferScreen(vm: TransferViewModel, prefs: DisplayPrefs) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val send by vm.send.collectAsState()
    val p by vm.prefs.collectAsState()
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pending?.invoke(); pending = null
    }

    /** Traži dopuštenja (Wi-Fi Direct, mediji, obavijesti) pa pokreće radnju bez obzira na ishod –
     *  ako nešto nedostaje, prijenos javlja jasnu pogrešku. */
    fun withPermissions(media: Boolean, action: () -> Unit) {
        val all = mutableListOf<String>()
        if (p.directMode) all += P2pLink.permissions()
        if (media) all += StorageAccess.mediaPermissions()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) all += Manifest.permission.POST_NOTIFICATIONS
        val need = missing(context, all.toTypedArray())
        if (need.isEmpty()) action() else { pending = action; launcher.launch(need) }
    }

    BackHandler(enabled = send.setup && state is TransferState.Idle) { vm.closeSendSetup() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(if (send.setup && state is TransferState.Idle) R.string.transfer_send_title else R.string.transfer_title)) },
                navigationIcon = {
                    if (send.setup && state is TransferState.Idle) {
                        IconButton(onClick = { vm.closeSendSetup() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
                    }
                }
            )
        },
        bottomBar = {
            if (send.setup && state is TransferState.Idle && send.items != null) {
                Surface(tonalElevation = 3.dp) {
                    Button(
                        onClick = { withPermissions(media = false) { vm.startSending() } },
                        enabled = send.selected.isNotEmpty() && PairingCode.normalize(send.code) != null && (p.directMode || send.host.isNotBlank()),
                        modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
                    ) {
                        Icon(Icons.Filled.Send, null)
                        Spacer(Modifier.size(8.dp))
                        Text(stringResource(R.string.transfer_send_now, send.selected.size, formatSize(send.selectedBytes, prefs)))
                    }
                }
            }
        }
    ) { padding ->
        val modifier = Modifier.fillMaxSize().padding(padding)
        when {
            state !is TransferState.Idle -> StatusContent(state, vm, prefs, modifier)
            send.setup -> SendSetup(vm, send, p, prefs, modifier) { withPermissions(media = true) { vm.scan() } }
            else -> TransferHome(vm, p, modifier,
                onReceive = { withPermissions(media = p.skipExisting) { vm.startReceiving() } },
                onSend = { vm.openSendSetup() })
        }
    }
}

@Composable
private fun TransferHome(
    vm: TransferViewModel,
    p: hr.smartduplicatecleaner.data.settings.TransferPrefs,
    modifier: Modifier,
    onReceive: () -> Unit,
    onSend: () -> Unit
) {
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            BigAction(Icons.Filled.Download, stringResource(R.string.transfer_receive), stringResource(R.string.transfer_receive_hint), onReceive)
        }
        item {
            BigAction(Icons.Filled.Upload, stringResource(R.string.transfer_send), stringResource(R.string.transfer_send_hint), onSend)
        }
        item {
            SectionTitle(stringResource(R.string.transfer_connection))
            RadioLine(p.directMode, stringResource(R.string.transfer_mode_direct)) { vm.update { it.copy(directMode = true) } }
            RadioLine(!p.directMode, stringResource(R.string.transfer_mode_network)) { vm.update { it.copy(directMode = false) } }
            Text(stringResource(R.string.transfer_mode_hint), style = MaterialTheme.typography.bodySmall)
            SectionTitle(stringResource(R.string.section_background))
            Toggle(stringResource(R.string.transfer_background), p.background) { on -> vm.update { it.copy(background = on) } }
            Toggle(stringResource(R.string.keep_screen_on_transfer), p.keepScreenOn) { on -> vm.update { it.copy(keepScreenOn = on) } }
            Text(stringResource(R.string.transfer_background_hint), style = MaterialTheme.typography.bodySmall)
            SectionTitle(stringResource(R.string.transfer_receiving_options))
            Toggle(stringResource(R.string.transfer_skip_existing), p.skipExisting) { on -> vm.update { it.copy(skipExisting = on) } }
            Text(
                stringResource(if (StorageAccess.hasAllFilesAccess()) R.string.transfer_dest_exact else R.string.transfer_dest_media),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun BigAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, hint: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Column(Modifier.padding(start = 16.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun Toggle(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SendSetup(
    vm: TransferViewModel,
    send: SendUi,
    p: hr.smartduplicatecleaner.data.settings.TransferPrefs,
    prefs: DisplayPrefs,
    modifier: Modifier,
    onScan: () -> Unit
) {
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            SectionTitle(stringResource(R.string.transfer_what))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TransferCategory.entries.forEach { c ->
                    FilterChip(
                        selected = c in p.categories,
                        onClick = { vm.update { s -> s.copy(categories = if (c in s.categories) s.categories - c else s.categories + c) } },
                        label = { Text(categoryName(c)) }
                    )
                }
            }
            if (TransferCategory.APPS in p.categories) Text(stringResource(R.string.transfer_apps_hint), style = MaterialTheme.typography.bodySmall)
            if (!StorageAccess.hasAllFilesAccess() && p.categories.any { it in NON_MEDIA }) {
                Text(stringResource(R.string.transfer_documents_hint), style = MaterialTheme.typography.bodySmall)
            }
            SectionTitle(stringResource(R.string.date_range_title))
            IntervalPicker(
                enabled = p.intervalEnabled, from = p.from, to = p.to, prefs = prefs,
                onEnabled = { on -> vm.update { it.copy(intervalEnabled = on) } },
                onChange = { f, t -> vm.update { it.copy(from = f, to = t) } }
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = onScan, enabled = !send.scanning && p.categories.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Search, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.transfer_scan))
            }
            if (send.scanning) Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(24.dp)); Text(stringResource(R.string.phase_listing), Modifier.padding(start = 12.dp))
            }
        }
        val items = send.items
        if (items != null) {
            item {
                SectionTitle(stringResource(R.string.transfer_found, items.size, formatSize(items.sumOf { it.size }, prefs)))
                Text(stringResource(R.string.transfer_folders_hint), style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(onClick = { vm.setAllFolders(true) }) { Text(stringResource(R.string.select_all)) }
                    TextButton(onClick = { vm.setAllFolders(false) }) { Text(stringResource(R.string.select_none)) }
                }
            }
            items(send.folders, key = { it.dir }) { f ->
                Row(Modifier.fillMaxWidth().clickable { vm.toggleFolder(f.dir) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = f.dir !in send.excluded, onCheckedChange = { vm.toggleFolder(f.dir) })
                    Column(Modifier.weight(1f)) {
                        Text(f.dir.ifEmpty { "/" }, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            f.categories.map { categoryName(it) }.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text("${f.count} · ${formatSize(f.bytes, prefs)}", style = MaterialTheme.typography.labelMedium)
                }
            }
            item {
                SectionTitle(stringResource(R.string.transfer_code_title))
                OutlinedTextField(
                    value = send.code, onValueChange = { vm.setCode(it) }, singleLine = true,
                    label = { Text(stringResource(R.string.transfer_code_label)) },
                    placeholder = { Text("K7QM-4XPA") },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.fillMaxWidth()
                )
                if (!p.directMode) {
                    OutlinedTextField(
                        value = send.host, onValueChange = { vm.setHost(it) }, singleLine = true,
                        label = { Text(stringResource(R.string.transfer_address_label)) },
                        placeholder = { Text("192.168.1.23") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    )
                }
                Text(stringResource(R.string.transfer_code_hint), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private val NON_MEDIA = setOf(TransferCategory.DOCUMENTS, TransferCategory.ARCHIVES, TransferCategory.APK_FILES, TransferCategory.OTHER)

@Composable
private fun StatusContent(state: TransferState, vm: TransferViewModel, prefs: DisplayPrefs, modifier: Modifier) {
    val context = LocalContext.current
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (state) {
            is TransferState.Preparing -> item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        stringResource(if (state.role == TransferRole.SEND) R.string.transfer_connecting else R.string.transfer_preparing),
                        Modifier.padding(16.dp), textAlign = TextAlign.Center
                    )
                    OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                }
            }
            is TransferState.Waiting -> item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.transfer_your_code), style = MaterialTheme.typography.titleMedium)
                        Text(
                            PairingCode.display(state.code),
                            fontSize = 44.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 12.dp)
                        )
                        state.address?.let {
                            Text(stringResource(R.string.transfer_your_address, it), style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace)
                        }
                        Text(stringResource(R.string.transfer_waiting_hint), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
            }
            is TransferState.Active -> item {
                val pr = state.progress
                val bps = pr.bytesPerSecond()
                val eta = if (bps > 0) (pr.bytesTotal - pr.bytesDone).coerceAtLeast(0) / bps else -1
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            stringResource(if (state.role == TransferRole.SEND) R.string.transfer_sending else R.string.transfer_receiving),
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                        )
                        if (state.peer.isNotBlank()) Text(state.peer, style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(
                            progress = { if (pr.bytesTotal > 0) pr.bytesDone.toFloat() / pr.bytesTotal else 0f },
                            modifier = Modifier.fillMaxWidth().height(8.dp)
                        )
                        Text(stringResource(R.string.transfer_files_progress, pr.filesDone, pr.filesTotal))
                        Text(formatSize(pr.bytesDone, prefs) + " / " + formatSize(pr.bytesTotal, prefs))
                        Text(stringResource(R.string.transfer_speed, formatSize(bps, prefs) + "/s"), fontWeight = FontWeight.SemiBold)
                        if (eta >= 0) Text(stringResource(R.string.transfer_eta, formatDuration(eta)))
                        if (pr.failed > 0) Text(stringResource(R.string.report_failed, pr.failed), color = MaterialTheme.colorScheme.error)
                        OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
                Text(stringResource(R.string.transfer_active_hint), style = MaterialTheme.typography.bodySmall)
            }
            is TransferState.Finished -> {
                val r = state.result
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                stringResource(if (r.cancelled) R.string.transfer_cancelled else R.string.transfer_done),
                                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                            )
                            Text(stringResource(R.string.transfer_done_files, r.succeeded.size, formatSize(r.bytes, prefs)))
                            val secs = (r.millis / 1000).coerceAtLeast(1)
                            Text(stringResource(R.string.transfer_done_time, formatDuration(secs), formatSize(r.bytes / secs, prefs) + "/s"))
                            if (r.skipped.isNotEmpty()) Text(stringResource(R.string.transfer_done_skipped, r.skipped.size))
                            if (r.failed.isNotEmpty()) Text(stringResource(R.string.report_failed, r.failed.size), color = MaterialTheme.colorScheme.error)
                            Button(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.done)) }
                        }
                    }
                }
                if (state.role == TransferRole.RECEIVE && state.apps.isNotEmpty()) {
                    item {
                        SectionTitle(stringResource(R.string.transfer_apps_received, state.apps.size))
                        Text(
                            stringResource(if (ApkInstaller.isAvailable) R.string.transfer_apps_install_hint else R.string.transfer_apps_saved_hint),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (ApkInstaller.isAvailable) items(state.apps, key = { it.label }) { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(app.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = {
                                if (!ApkInstaller.canInstall(context)) context.startActivity(ApkInstaller.permissionIntent(context))
                                else try { ApkInstaller.install(context, app) } catch (e: Exception) { }
                            }) { Text(stringResource(R.string.transfer_install)) }
                        }
                    }
                }
                if (r.failed.isNotEmpty()) {
                    item { SectionTitle(stringResource(R.string.errors)) }
                    items(r.failed.take(200), key = { "f" + it.first.id }) { (item, reason) ->
                        Text(item.relativeDir + item.name + " – " + reason, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            is TransferState.Failed -> item {
                FailureCard(state, prefs) { vm.reset() }
            }
            TransferState.Idle -> Unit
        }
    }
}

@Composable
private fun FailureCard(state: TransferState.Failed, prefs: DisplayPrefs, onOk: () -> Unit) {
    val context = LocalContext.current
    val text = when (state.reason) {
        TransferFailure.NO_PERMISSION -> stringResource(R.string.tr_err_permission)
        TransferFailure.WIFI_OFF -> stringResource(R.string.tr_err_wifi)
        TransferFailure.LOCATION_OFF -> stringResource(R.string.tr_err_location)
        TransferFailure.P2P_UNSUPPORTED -> stringResource(R.string.tr_err_unsupported)
        TransferFailure.P2P_FAILED -> stringResource(R.string.tr_err_p2p)
        TransferFailure.NOT_FOUND -> stringResource(R.string.tr_err_not_found)
        TransferFailure.CONNECT_FAILED -> stringResource(R.string.tr_err_connect)
        TransferFailure.AUTH_FAILED -> stringResource(R.string.tr_err_code)
        TransferFailure.BUSY -> stringResource(R.string.tr_err_busy)
        TransferFailure.NO_SPACE -> stringResource(R.string.tr_err_space, if (state.freeBytes >= 0) formatSize(state.freeBytes, prefs) else "?")
        TransferFailure.PORT_IN_USE -> stringResource(R.string.tr_err_port)
        TransferFailure.NO_NETWORK -> stringResource(R.string.tr_err_network)
        TransferFailure.UNKNOWN -> stringResource(R.string.fail_unknown)
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NoticeCard(text)
        when (state.reason) {
            TransferFailure.WIFI_OFF, TransferFailure.NO_NETWORK ->
                OutlinedButton(onClick = { context.startActivity(TransferManager.wifiSettingsIntent()) }) { Text(stringResource(R.string.tr_open_wifi)) }
            TransferFailure.LOCATION_OFF ->
                OutlinedButton(onClick = { context.startActivity(TransferManager.locationSettingsIntent()) }) { Text(stringResource(R.string.tr_open_location)) }
            TransferFailure.NO_PERMISSION ->
                OutlinedButton(onClick = { context.startActivity(StorageAccess.appSettingsIntent(context)) }) { Text(stringResource(R.string.open_app_settings)) }
            else -> Unit
        }
        Button(onClick = onOk, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.ok)) }
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
