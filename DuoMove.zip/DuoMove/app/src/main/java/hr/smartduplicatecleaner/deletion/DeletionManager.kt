package hr.smartduplicatecleaner.deletion

import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import hr.smartduplicatecleaner.core.logic.DeleteOutcome
import hr.smartduplicatecleaner.core.logic.FailureReason
import hr.smartduplicatecleaner.core.logic.FileDeleter
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.data.db.AppDatabase
import hr.smartduplicatecleaner.data.db.RecoveryEntity
import hr.smartduplicatecleaner.storage.StorageAccess
import java.io.File
import java.io.IOException
import java.util.UUID

/** Načini oporavka zapisani u bazi. */
object RecoveryMethod {
    const val MEDIA_TRASH = "MEDIA_TRASH"
    const val SAF_COPY = "SAF_COPY"
    const val FILE_MOVE = "FILE_MOVE"
}

/**
 * Stvarno brisanje datoteka na Androidu.
 *
 * - MediaStore datoteke: sistemski dijalog (MediaStore.createDeleteRequest ili createTrashRequest).
 *   Android sam traži korisnikovu potvrdu – aplikacija ne može zaobići taj korak.
 * - SAF datoteke: DocumentsContract.deleteDocument (uz prethodnu kopiju u mapu za oporavak).
 * - Datotečni sustav: premještanje u mapu za oporavak ili File.delete (samo uz "Pristup svim datotekama").
 */
class DeletionManager(private val context: Context, db: AppDatabase) {
    private val resolver: ContentResolver get() = context.contentResolver
    private val recoveryDao = db.recovery()

    // ---------- Provjera prije brisanja ----------

    /** Postoji li datoteka i je li nepromijenjene veličine od skeniranja. */
    fun validity(file: ScannedFile): FailureReason? {
        if (StorageAccess.isProtectedDir(file.relativeDir)) return FailureReason.PERMISSION_DENIED
        return try {
            val size = when (file.source) {
                SourceType.FILE_SYSTEM -> File(file.absolutePath ?: return FailureReason.NOT_FOUND)
                    .takeIf { it.exists() }?.length()
                SourceType.MEDIA_STORE -> querySize(Uri.parse(file.uri), MediaStore.MediaColumns.SIZE)
                SourceType.SAF_TREE -> querySize(Uri.parse(file.uri), DocumentsContract.Document.COLUMN_SIZE)
            }
            when {
                size == null -> FailureReason.NOT_FOUND
                size != file.sizeBytes -> FailureReason.CHANGED_SINCE_SCAN
                else -> null
            }
        } catch (e: SecurityException) {
            FailureReason.PERMISSION_DENIED
        } catch (e: Exception) {
            FailureReason.NOT_FOUND
        }
    }

    private fun querySize(uri: Uri, column: String): Long? =
        resolver.query(uri, arrayOf(column), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }

    // ---------- SAF i datotečni sustav ----------

    /** Brisač za SAF i datotečni sustav; [recoverable] = najprije sačuvaj kopiju za oporavak. */
    fun directDeleter(recoverable: Boolean): FileDeleter = FileDeleter { file ->
        when (file.source) {
            SourceType.SAF_TREE -> deleteSaf(file, recoverable)
            SourceType.FILE_SYSTEM -> deleteFile(file, recoverable)
            SourceType.MEDIA_STORE -> DeleteOutcome.Failed(FailureReason.UNKNOWN, "media")
        }
    }

    private fun deleteSaf(file: ScannedFile, recoverable: Boolean): DeleteOutcome {
        val uri = Uri.parse(file.uri)
        val copy: File? = if (recoverable) {
            val dir = File(context.getExternalFilesDir(null), "recovery").apply { mkdirs() }
            val target = File(dir, UUID.randomUUID().toString() + "_" + file.name)
            val copied = (resolver.openInputStream(uri) ?: throw IOException("open")).use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            }
            if (copied != file.sizeBytes) {
                target.delete()
                return DeleteOutcome.Failed(FailureReason.IO_ERROR, "copy")
            }
            target
        } else null
        val deleted = try {
            DocumentsContract.deleteDocument(resolver, uri)
        } catch (e: Exception) {
            copy?.delete()
            throw e
        }
        if (!deleted) {
            copy?.delete()
            return DeleteOutcome.Failed(FailureReason.IO_ERROR)
        }
        if (copy != null) {
            val docId = file.documentId
            val parent = docId?.takeIf { it.contains(':') }?.let {
                val path = it.substringAfter(':')
                it.substringBefore(':') + ":" + path.substringBeforeLast('/', "")
            }
            val id = insertRecovery(
                RecoveryEntity(
                    name = file.name, displayPath = file.displayPath, sizeBytes = file.sizeBytes, mimeType = file.mimeType,
                    deletedAt = System.currentTimeMillis(), method = RecoveryMethod.SAF_COPY, mediaUri = null,
                    recoveredPath = copy.absolutePath, treeUri = file.treeUri, parentDocumentId = parent, originalAbsolutePath = null
                )
            )
            return DeleteOutcome.Done(id.toString())
        }
        return DeleteOutcome.Done()
    }

    private fun deleteFile(file: ScannedFile, recoverable: Boolean): DeleteOutcome {
        if (!StorageAccess.hasAllFilesAccess()) return DeleteOutcome.Failed(FailureReason.PERMISSION_DENIED)
        val f = File(file.absolutePath ?: return DeleteOutcome.Failed(FailureReason.NOT_FOUND))
        if (!f.exists()) return DeleteOutcome.Failed(FailureReason.NOT_FOUND)
        if (!recoverable) {
            if (!f.delete()) return DeleteOutcome.Failed(FailureReason.IO_ERROR)
            scan(f.absolutePath)
            return DeleteOutcome.Done()
        }
        val root = volumeRoot(f, file)
        val dir = File(root, StorageAccess.RECOVERY_DIR).apply { mkdirs() }
        // .nomedia sprječava da galerija i MediaStore prikazuju datoteke u mapi za oporavak.
        File(dir, ".nomedia").let { if (!it.exists()) it.createNewFile() }
        val target = File(dir, System.currentTimeMillis().toString() + "_" + f.name)
        val moved = f.renameTo(target) || run {
            f.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            target.length() == f.length() && f.delete()
        }
        if (!moved) {
            if (target.exists() && f.exists()) target.delete()
            return DeleteOutcome.Failed(FailureReason.IO_ERROR)
        }
        scan(f.absolutePath)
        val id = insertRecovery(
            RecoveryEntity(
                name = file.name, displayPath = file.displayPath, sizeBytes = file.sizeBytes, mimeType = file.mimeType,
                deletedAt = System.currentTimeMillis(), method = RecoveryMethod.FILE_MOVE, mediaUri = null,
                recoveredPath = target.absolutePath, treeUri = null, parentDocumentId = null, originalAbsolutePath = f.absolutePath
            )
        )
        return DeleteOutcome.Done(id.toString())
    }

    private fun volumeRoot(f: File, file: ScannedFile): File {
        val suffix = (file.relativeDir + file.name).trimStart('/')
        val abs = f.absolutePath
        return if (abs.endsWith(suffix)) File(abs.removeSuffix(suffix).trimEnd('/')) else f.parentFile ?: f
    }

    private fun scan(path: String) {
        MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
    }

    private fun insertRecovery(e: RecoveryEntity): Long =
        kotlinx.coroutines.runBlocking { recoveryDao.insert(e) }

    // ---------- MediaStore (sistemski dijalog) ----------

    /** Zahtjev za brisanje ili premještanje u koš – vraća PendingIntent čiji dijalog prikazuje Android. */
    fun mediaRequest(uris: List<Uri>, trash: Boolean): PendingIntent =
        if (trash) MediaStore.createTrashRequest(resolver, uris, true)
        else MediaStore.createDeleteRequest(resolver, uris)

    fun mediaRestoreRequest(uris: List<Uri>): PendingIntent = MediaStore.createTrashRequest(resolver, uris, false)

    /** Stanje medijske datoteke nakon sistemskog dijaloga. */
    enum class MediaState { PRESENT, TRASHED, GONE }

    fun mediaState(uri: Uri): MediaState = try {
        val args = Bundle().apply { putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_INCLUDE) }
        resolver.query(uri, arrayOf(MediaStore.MediaColumns.IS_TRASHED), args, null)?.use { c ->
            when {
                !c.moveToFirst() -> MediaState.GONE
                c.getInt(0) == 1 -> MediaState.TRASHED
                else -> MediaState.PRESENT
            }
        } ?: MediaState.GONE
    } catch (e: Exception) {
        MediaState.GONE
    }

    /**
     * Provjera ishoda sistemskog dijaloga za svaku datoteku – izvještaj se temelji na stvarnom
     * stanju, a ne na pretpostavci da je sve uspjelo.
     */
    suspend fun verifyMedia(files: List<ScannedFile>, trash: Boolean, userApproved: Boolean): List<Pair<ScannedFile, DeleteOutcome>> =
        files.map { f ->
            val state = mediaState(Uri.parse(f.uri))
            val ok = if (trash) state == MediaState.TRASHED else state == MediaState.GONE
            when {
                ok && trash -> {
                    val id = recoveryDao.insert(
                        RecoveryEntity(
                            name = f.name, displayPath = f.displayPath, sizeBytes = f.sizeBytes, mimeType = f.mimeType,
                            deletedAt = System.currentTimeMillis(), method = RecoveryMethod.MEDIA_TRASH, mediaUri = f.uri,
                            recoveredPath = null, treeUri = null, parentDocumentId = null, originalAbsolutePath = null
                        )
                    )
                    f to DeleteOutcome.Done(id.toString())
                }
                ok -> f to DeleteOutcome.Done()
                !userApproved -> f to DeleteOutcome.Failed(FailureReason.USER_DECLINED)
                else -> f to DeleteOutcome.Failed(FailureReason.UNKNOWN)
            }
        }

    // ---------- Oporavak ----------

    /** Vraćanje SAF kopije ili premještene datoteke. MEDIA_TRASH ide preko sistemskog dijaloga. */
    fun restoreLocal(e: RecoveryEntity): Boolean = when (e.method) {
        RecoveryMethod.FILE_MOVE -> {
            val src = File(e.recoveredPath ?: "")
            val dst = File(e.originalAbsolutePath ?: "")
            if (!src.exists() || dst.exists()) false
            else {
                dst.parentFile?.mkdirs()
                val ok = src.renameTo(dst)
                if (ok) scan(dst.absolutePath)
                ok
            }
        }
        RecoveryMethod.SAF_COPY -> {
            val src = File(e.recoveredPath ?: "")
            val tree = e.treeUri?.let { Uri.parse(it) }
            if (!src.exists() || tree == null) false
            else {
                val parentId = e.parentDocumentId ?: DocumentsContract.getTreeDocumentId(tree)
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
                val created = DocumentsContract.createDocument(resolver, parent, e.mimeType ?: "application/octet-stream", e.name)
                if (created == null) false
                else {
                    val copied = (resolver.openOutputStream(created) ?: throw IOException("open")).use { out ->
                        src.inputStream().use { it.copyTo(out) }
                    }
                    if (copied == e.sizeBytes) { src.delete(); true } else false
                }
            }
        }
        else -> false
    }

    /** Trajno brisanje lokalne kopije za oporavak. */
    fun purgeLocal(e: RecoveryEntity): Boolean {
        val f = File(e.recoveredPath ?: return true)
        return !f.exists() || f.delete()
    }

    /** Postoji li još sačuvana kopija (koš se na Androidu sam prazni nakon ~30 dana). */
    fun isRecoverable(e: RecoveryEntity): Boolean = when (e.method) {
        RecoveryMethod.MEDIA_TRASH -> e.mediaUri != null && mediaState(Uri.parse(e.mediaUri)) == MediaState.TRASHED
        else -> e.recoveredPath != null && File(e.recoveredPath).exists()
    }

    suspend fun removeRecords(ids: List<Long>) = recoveryDao.delete(ids)
    suspend fun allRecords(): List<RecoveryEntity> = recoveryDao.list()
}
