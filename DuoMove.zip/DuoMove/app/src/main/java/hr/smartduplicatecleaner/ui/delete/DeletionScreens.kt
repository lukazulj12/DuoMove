package hr.smartduplicatecleaner.ui.delete

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.logic.DeletionPlan
import hr.smartduplicatecleaner.core.logic.PlanResult
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.data.settings.DeletionMode
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.FileThumbnail
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.failureLabel
import hr.smartduplicatecleaner.ui.components.formatSize
import hr.smartduplicatecleaner.ui.results.DeletionUi
import hr.smartduplicatecleaner.ui.results.ReviewViewModel
import hr.smartduplicatecleaner.ui.theme.LocalStatusColors

/**
 * Zaslon s KONAČNIM popisom datoteka koje će se izbrisati, ukupnim brojem i oslobođenim prostorom.
 * Brisanje kreće tek nakon izričite potvrde u dijalogu.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeletionReviewScreen(
    vm: ReviewViewModel,
    prefs: DisplayPrefs,
    mode: DeletionMode,
    onBack: () -> Unit,
    onFinished: () -> Unit
) {
    LaunchedEffect(Unit) { vm.preparePlan() }
    val planResult by vm.plan.collectAsState()
    val deletion by vm.deletion.collectAsState()
    var confirm by remember { mutableStateOf(false) }
    val sc = LocalStatusColors.current

    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        vm.onConsentResult(result.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(deletion) {
        when (val d = deletion) {
            is DeletionUi.AwaitingConsent -> if (vm.claimConsentLaunch()) {
                consentLauncher.launch(IntentSenderRequest.Builder(d.intentSender).build())
            }
            is DeletionUi.Finished -> onFinished()
            else -> Unit
        }
    }
    val busy = deletion is DeletionUi.Running || deletion is DeletionUi.AwaitingConsent
    BackHandler(enabled = busy) { /* tijekom brisanja povratak nije dopušten */ }

    val plan: DeletionPlan? = (planResult as? PlanResult.Ready)?.plan

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.final_review_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
                }
            )
        },
        bottomBar = {
            if (plan != null) Surface(tonalElevation = 3.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (val d = deletion) {
                        is DeletionUi.Running -> {
                            LinearProgressIndicator(progress = { if (d.total > 0) d.done.toFloat() / d.total else 0f }, modifier = Modifier.fillMaxWidth())
                            Text(stringResource(R.string.deleting_progress, d.done, d.total))
                        }
                        is DeletionUi.AwaitingConsent -> Text(stringResource(R.string.waiting_system_confirmation, d.count))
                        else -> Button(
                            onClick = { confirm = true },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = sc.delete, contentColor = sc.onDelete)
                        ) {
                            Icon(Icons.Filled.Delete, null)
                            Spacer(Modifier.size(8.dp))
                            Text(stringResource(R.string.confirm_delete), style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    ) { padding ->
        when (val r = planResult) {
            null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            PlanResult.Empty -> Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.nothing_marked))
            }
            is PlanResult.Rejected -> Column(Modifier.padding(padding).padding(16.dp)) {
                NoticeCard(stringResource(R.string.plan_rejected, r.emptyGroups.size + r.missingFiles.size))
            }
            is PlanResult.Ready -> LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.files_to_delete, r.plan.count), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.space_to_free, formatSize(r.plan.totalBytes, prefs)), style = MaterialTheme.typography.titleMedium)
                            Text(
                                stringResource(if (mode == DeletionMode.RECOVERABLE) R.string.mode_recoverable_info else R.string.mode_permanent_info),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (r.plan.items.any { it.source == SourceType.MEDIA_STORE }) {
                                Text(stringResource(R.string.system_dialog_info), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                items(r.plan.items, key = { it.key }) { f -> PlanRow(f, prefs) }
            }
        }
    }

    if (confirm && plan != null) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.confirm_delete)) },
            text = {
                Text(
                    stringResource(
                        if (mode == DeletionMode.RECOVERABLE) R.string.confirm_delete_text_recoverable else R.string.confirm_delete_text_permanent,
                        plan.count, formatSize(plan.totalBytes, prefs)
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.execute(plan) }) {
                    Text(stringResource(R.string.delete_now), color = sc.delete, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
private fun PlanRow(f: ScannedFile, prefs: DisplayPrefs) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FileThumbnail(f, Modifier.size(52.dp), sizePx = 160)
        Column(Modifier.weight(1f)) {
            Text(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(f.relativeDir.ifEmpty { "/" }, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(formatSize(f.sizeBytes, prefs), style = MaterialTheme.typography.bodySmall)
    }
}

/** Izvještaj nakon brisanja: uspješno obrisane datoteke, oslobođeni prostor i pogreške. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeletionReportScreen(vm: ReviewViewModel, prefs: DisplayPrefs, onDone: () -> Unit) {
    val deletion by vm.deletion.collectAsState()
    val report = (deletion as? DeletionUi.Finished)?.report
    BackHandler { vm.resetDeletion(); onDone() }
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.report_title)) }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { vm.resetDeletion(); onDone() },
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(52.dp)
                ) { Text(stringResource(R.string.done)) }
            }
        }
    ) { padding ->
        if (report == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { Text(stringResource(R.string.nothing_marked)) }
            return@Scaffold
        }
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.report_success, report.succeeded.size), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.freed_space, formatSize(report.freedBytes, prefs)), style = MaterialTheme.typography.titleMedium)
                        if (report.recoverable && report.succeeded.isNotEmpty()) {
                            Text(stringResource(R.string.report_recoverable_hint), style = MaterialTheme.typography.bodySmall)
                        }
                        if (report.failed.isNotEmpty()) {
                            Text(stringResource(R.string.report_failed, report.failed.size), color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            if (report.failed.isNotEmpty()) {
                item { Text(stringResource(R.string.errors), style = MaterialTheme.typography.titleSmall) }
                items(report.failed, key = { it.first.key }) { (f, failure) ->
                    Column {
                        Text(f.displayPath, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(failureLabel(failure.reason), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        HorizontalDivider(Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}
