# Rezultati testova – DuoMove

Datum izvođenja: 1. 11. 2026. Okruženje: Linux, OpenJDK 21, Kotlin 2.0.21, JUnit 4.13.2.

- **`core`**: 57 testova, svi prolaze (duplikati, prioritet mapa, prepoznavanje datuma u nazivima, izmjena datuma u MP4,
  prijenos preko stvarnih TCP veza na 127.0.0.1).
- **`app`**: test potpunosti hrvatskog i engleskog prijevoda (3 testa) i `tools/check_resources.py` (404 teksta).
- **Nije izvršeno ovdje:** kompajliranje Android koda, izgradnja APK-a i rad na stvarnim mobitelima (Android SDK nije bio dostupan).
  GitHub workflow pokreće `:core:test :app:testFullDebugUnitTest :app:assembleFullDebug`.

## Novi testovi

| Područje | Test | Što provjerava |
|---|---|---|
| Datumi iz naziva | `userExamples` | IMG-20261028-WA0014.JPG → 28. 10. 2026.; VID_20250705_105923_016.MP4 → 5. 7. 2025. 10:59:23 |
| | `commonFormats` | Screenshot_…, PXL_…, DD.MM.GGGG, DD-MM-GGGG, GGGGMMDD_HHmmss, Unix ms |
| | `noDateOrImplausible_returnsNull` | bez datuma, budućnost, prije 1990., nemoguć datum |
| | `ddmmVsMmdd` | jedinstveno tumačenje, 4 postavke za dvosmislene datume |
| | `customPatterns` | ručni oblici, prednost pred automatikom, provjera neispravnih oblika |
| | `planner_detectsMismatch_andSkipsNamesWithoutDate` | neusklađen / ispravan / bez datuma, interval po nazivu i po trenutačnom datumu, usporedba vremena |
| MP4 datum | `writesAllDateFields_inPlace_keepingSizeAndMediaData` | mvhd/tkhd/mdhd (v0 i v1), moov na početku i kraju, 64-bitna kutija, sadržaj netaknut |
| | `notMp4_isRejected_withoutChanges` | datoteka koja nije MP4 ostaje nepromijenjena |
| Prijenos | `parallelTransfer_allFilesArriveIntact` | 120 datoteka (0 B – 3,5 MB) preko 4 paralelne veze, bajt po bajt jednake |
| | `wrongCode_isRejected_andNothingWritten` | pogrešan kod |
| | `skipExisting_noSpace_andSourceErrors` | preskakanje postojećih, izvor nestao tijekom slanja, nema mjesta |
| | `cancel_stopsTransfer_andReceiverDiscardsPartialFiles` | otkazivanje, primatelj ne sprema djelomične datoteke |
| | `maliciousPaths_areSanitized` | "../" putanje |
| | `pairingCode_and_classifier` | kod za uparivanje, lozinka mreže, razvrstavanje APK/arhiva |

## Izlaz izvođenja

```
== core ==
  OK  ScanScenariosTest.samePhysicalFileFromTwoSources_isNotItsOwnDuplicate
  OK  ScanScenariosTest.exifVersusNoExif_fallbackIsLabelled_andCaptureOnlySkips
  OK  ScanScenariosTest.recompressedSmallerCopy_isVisualDuplicate_andOlderLargerIsKept
  OK  ScanScenariosTest.sameNameIdenticalContent_isExactGroup
  OK  ScanScenariosTest.identicalPhotosDifferentNames_areFound
  OK  ScanScenariosTest.differentSizeAndResolution_rulesRespected
  OK  ScanScenariosTest.deniedSource_isReported_andOtherSourcesStillScanned
  OK  ScanScenariosTest.emptyFiles_areIgnored
  OK  ScanScenariosTest.unreadableFile_isNeverReportedAsDuplicate
  OK  ScanScenariosTest.categoryAndFolderFilters_applied
  OK  ScanScenariosTest.cancellation_stopsScan
  OK  ScanScenariosTest.filesAboveLimit_areExcludedAndReported
  OK  ScanScenariosTest.copiedPhotoWithNewFileDate_keepsOriginalByCaptureDate_orAsksUser
  OK  ScanScenariosTest.sameNameDifferentContent_isSameNameGroupWithoutAutoSuggestion
  OK  ScanScenariosTest.manyFiles_andOutOfMemory_handledGracefully
  OK  SelectionAndDeletionTest.undecidedGroups_neverAutoMarked
  OK  SelectionAndDeletionTest.runnerDeletesOnlyConfirmedFiles
  OK  SelectionAndDeletionTest.changedSinceScan_isNotDeleted
  OK  SelectionAndDeletionTest.manualChangeOfAutomaticSelection
  OK  SelectionAndDeletionTest.crossGroupProtection_fileInTwoGroups
  OK  SelectionAndDeletionTest.cannotMarkAllFilesInGroup
  OK  SelectionAndDeletionTest.errorsDuringDeletion_areReported_andDoNotStopOthers
  OK  SelectionAndDeletionTest.planRejectsUnknownFiles
  OK  SelectionAndDeletionTest.onlyConfirmed_ignoresVisualGroups
  OK  SelectionAndDeletionTest.corruptedSavedState_withAllMarked_isSanitized
  OK  HashAndRulesTest.missingResolution_skipsCriterion_neverGuesses
  OK  HashAndRulesTest.exifOrientation_makesRotatedCopiesMatch
  OK  HashAndRulesTest.reasonEncoding_roundTrip
  OK  HashAndRulesTest.similarGroup_isAdvisoryOnly
  OK  HashAndRulesTest.rulePriority_primarySecondaryTertiary
  OK  HashAndRulesTest.exifDateParser_validatesValues
  OK  HashAndRulesTest.similarityThreshold_mapping
  OK  HashAndRulesTest.classifier
  OK  HashAndRulesTest.newerPreference_andDisabledRules
  OK  HashAndRulesTest.formatters
  OK  HashAndRulesTest.sha256_knownVector
  OK  HashAndRulesTest.perceptualHash_robustToScaleAndRecompression_butSeparatesDifferentPhotos
  OK  FolderPriorityAndDateTest.dateRange_usesEarliestKnownDate_notCopyDate
  OK  FolderPriorityAndDateTest.preferredOrder_decidesKeeper_evenAgainstOlderDate
  OK  FolderPriorityAndDateTest.demotedOrder_deletesFromMostSubordinateFirst
  OK  FolderPriorityAndDateTest.folderRule_canBeMovedBelowDate_orDisabled
  OK  FolderPriorityAndDateTest.scoring_orderAndSubfolders
  OK  FolderPriorityAndDateTest.dateRange_onlyFilesCreatedInInterval_areScanned
  OK  NameDateTest.customPatterns
  OK  NameDateTest.ddmmVsMmdd
  OK  NameDateTest.noDateOrImplausible_returnsNull
  OK  NameDateTest.commonFormats
  OK  NameDateTest.userExamples
  OK  NameDateTest.planner_detectsMismatch_andSkipsNamesWithoutDate
  OK  Mp4DatesTest.notMp4_isRejected_withoutChanges
  OK  Mp4DatesTest.writesAllDateFields_inPlace_keepingSizeAndMediaData
  OK  TransferTest.cancel_stopsTransfer_andReceiverDiscardsPartialFiles
  OK  TransferTest.parallelTransfer_allFilesArriveIntact
  OK  TransferTest.maliciousPaths_areSanitized
  OK  TransferTest.pairingCode_and_classifier
  OK  TransferTest.skipExisting_noSpace_andSourceErrors
  OK  TransferTest.wrongCode_isRejected_andNothingWritten
Ukupno: 57, neuspjelo: 0, trajanje: 1865 ms
== app (lokalizacija) ==
  OK  LocalizationResourcesTest.formatArgumentsMatch
  OK  LocalizationResourcesTest.keyCroatianTermsPresent
  OK  LocalizationResourcesTest.everyStringIsTranslated
Ukupno: 3, neuspjelo: 0, trajanje: 438 ms
== provjera resursa ==
EN: 404  HR: 403  korišteno: 404  nekorišteno: []
OK – lokalizacija je potpuna i dosljedna.
```
