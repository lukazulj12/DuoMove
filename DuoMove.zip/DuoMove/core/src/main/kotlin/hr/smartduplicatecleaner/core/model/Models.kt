package hr.smartduplicatecleaner.core.model

/**
 * Osnovni modeli podataka jezgre. Jezgra ne ovisi o Android API-jima,
 * pa se sva logika može testirati običnim JVM testovima.
 */

/** Kategorija datoteke prema MIME tipu ili ekstenziji. */
enum class FileCategory { IMAGE, VIDEO, AUDIO, DOCUMENT, ARCHIVE, OTHER }

/** Izvor iz kojeg je datoteka pronađena – određuje i način brisanja. */
enum class SourceType {
    /** MediaStore (slike, video, audio) – brisanje preko sistemskog dijaloga ili koša. */
    MEDIA_STORE,
    /** Mapa koju je korisnik odobrio preko Storage Access Frameworka. */
    SAF_TREE,
    /** Izravan pristup datotečnom sustavu (samo uz dopuštenje "Pristup svim datotekama"). */
    FILE_SYSTEM
}

/** Odakle potječe datum koji se koristi za usporedbu. */
enum class DateSource {
    /** DateTimeOriginal iz EXIF metapodataka fotografije. */
    EXIF,
    /** Datum snimanja iz metapodataka medija (npr. video) koje je izvukao MediaStore. */
    MEDIA_METADATA,
    /** Datum kada je datoteka dodana na uređaj (približno datum kopiranja). */
    DATE_ADDED,
    /** Datum posljednje izmjene datoteke. */
    LAST_MODIFIED
}

/**
 * Jedna pronađena datoteka s metapodacima i (opcionalno) izračunatim hashovima.
 *
 * @property key kanonski ključ fizičke datoteke (volumen + putanja, mala slova) ili URI
 *               ako putanju nije moguće utvrditi. Služi da se ista fizička datoteka,
 *               pronađena preko dva izvora, ne proglasi duplikatom same sebe.
 */
data class ScannedFile(
    val key: String,
    val uri: String,
    val source: SourceType,
    val name: String,
    val volume: String?,
    val relativeDir: String,
    val sizeBytes: Long,
    val mimeType: String?,
    val category: FileCategory,
    val dateTakenMillis: Long? = null,
    val dateTakenSource: DateSource? = null,
    val dateAddedMillis: Long? = null,
    val dateModifiedMillis: Long? = null,
    val width: Int? = null,
    val height: Int? = null,
    val treeUri: String? = null,
    val documentId: String? = null,
    val absolutePath: String? = null,
    val sha256: String? = null,
    val pHash: Long? = null,
    val dHash: Long? = null
) {
    /** Broj piksela ili null ako rezolucija nije poznata. */
    val pixelCount: Long?
        get() = if (width != null && height != null && width > 0 && height > 0) width.toLong() * height else null

    /** Putanja za prikaz korisniku. */
    val displayPath: String
        get() = relativeDir.trimEnd('/') + "/" + name

    /** Je li datoteka u mapi kamere (DCIM). */
    val isInCameraFolder: Boolean
        get() = relativeDir.startsWith("DCIM/", ignoreCase = true) || relativeDir.equals("DCIM", ignoreCase = true)
}

/** Vrsta grupe duplikata. */
enum class GroupType {
    /** Potpuno identične datoteke – potvrđeno SHA-256 hashom. */
    EXACT,
    /** Isti vizualni sadržaj (perceptualni hash), ali različiti bajtovi – npr. WhatsApp kopija. */
    VISUAL,
    /** Slične fotografije – potrebna je ručna provjera, nikad se ne označavaju automatski. */
    SIMILAR,
    /** Isti naziv, ali različit sadržaj – samo informativno, nikad se ne označavaju automatski. */
    SAME_NAME
}

/**
 * Član grupe.
 * @property contentLabel redni broj sadržaja unutar grupe (0 = A, 1 = B...). Datoteke s istim
 *           brojem imaju identičan sadržaj (isti SHA-256).
 */
data class GroupMember(val fileKey: String, val contentLabel: Int)

data class DuplicateGroup(
    val id: String,
    val type: GroupType,
    val category: FileCategory,
    val members: List<GroupMember>,
    /** Najveća perceptualna udaljenost unutar grupe (samo za slike), za prikaz postotka sličnosti. */
    val maxDistance: Int? = null
) {
    val fileKeys: List<String> get() = members.map { it.fileKey }

    /** Grupe iz kojih aplikacija smije automatski predložiti brisanje. */
    val allowsAutoSuggestion: Boolean get() = type == GroupType.EXACT || type == GroupType.VISUAL
}
