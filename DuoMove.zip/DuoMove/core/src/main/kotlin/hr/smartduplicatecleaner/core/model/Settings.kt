package hr.smartduplicatecleaner.core.model

/** Koji se datum koristi za pravilo "starija / novija datoteka". */
enum class DateKind {
    /** Datum snimanja (EXIF/metapodaci); ako ga nema, zamjenski najraniji poznati datum datoteke – jasno označen. */
    CAPTURE_WITH_FALLBACK,
    /** Samo datum snimanja; ako nedostaje ijednoj datoteci, kriterij se preskače. */
    CAPTURE_ONLY,
    /** Datum dodavanja na uređaj (približno datum kopiranja). */
    DATE_ADDED,
    /** Datum posljednje izmjene. */
    LAST_MODIFIED
}

enum class DatePreference { OLDER, NEWER, NONE }
enum class SizePreference { LARGER, SMALLER, NONE }

/** Kriteriji za odabir datoteke koju zadržavamo, poredani po prioritetu. */
enum class CriterionType { FOLDERS, DATE, SIZE, RESOLUTION }

/**
 * Prioritet mapa: do 3 povlaštene mape (prva ima najveću prednost) i do 3 podređene mape
 * (prva je najpodređenija – iz nje se duplikati brišu prije nego iz ostalih).
 * Mapa se zadaje relativnom putanjom, npr. "DCIM/Camera/"; obuhvaća i sve podmape.
 */
object FolderPriority {
    const val MAX = 3

    fun normalize(dir: String): String {
        val t = dir.trim().trim('/')
        return if (t.isEmpty()) "" else t.lowercase(java.util.Locale.ROOT) + "/"
    }

    /** Najdulja (najspecifičnija) mapa s popisa koja sadrži [relativeDir], ili -1. */
    fun matchIndex(relativeDir: String, folders: List<String>): Int {
        val d = normalize(relativeDir)
        var best = -1
        var bestLen = -1
        folders.take(MAX).forEachIndexed { i, f ->
            val n = normalize(f)
            if (n.isNotEmpty() && d.startsWith(n) && n.length > bestLen) { best = i; bestLen = n.length }
        }
        return best
    }

    /**
     * Ocjena mape: povlaštene 3, 2, 1 (redom), obične 0, podređene −3, −2, −1
     * (prva podređena je najniža). Ako se mapa nalazi na oba popisa, vrijedi specifičnija putanja.
     */
    fun score(relativeDir: String, preferred: List<String>, demoted: List<String>): Int {
        val p = matchIndex(relativeDir, preferred)
        val q = matchIndex(relativeDir, demoted)
        if (p < 0 && q < 0) return 0
        if (q < 0) return MAX - p
        if (p < 0) return -(MAX - q)
        val pl = normalize(preferred[p]).length
        val ql = normalize(demoted[q]).length
        return if (pl >= ql) MAX - p else -(MAX - q)
    }

    /** Uobičajene mape za brzi odabir u postavkama. */
    val SUGGESTIONS = listOf(
        "DCIM/Camera/",
        "Pictures/Screenshots/",
        "DCIM/Screenshots/",
        "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/",
        "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video/",
        "Pictures/Viber/",
        "Pictures/Messenger/",
        "Pictures/Instagram/",
        "Pictures/Telegram/",
        "Download/"
    )
}

data class KeepRules(
    val order: List<CriterionType> = DEFAULT_ORDER,
    val datePreference: DatePreference = DatePreference.OLDER,
    val dateKind: DateKind = DateKind.CAPTURE_WITH_FALLBACK,
    val sizePreference: SizePreference = SizePreference.LARGER,
    val preferHigherResolution: Boolean = true,
    /** Uključuje/isključuje pravilo prioriteta mapa (popisi ostaju sačuvani). */
    val useFolderPriority: Boolean = true,
    /** Povlaštene mape, redom prioriteta (najviše 3). */
    val preferredFolders: List<String> = emptyList(),
    /** Podređene mape, prva je najpodređenija (najviše 3). */
    val demotedFolders: List<String> = emptyList()
) {
    fun isEnabled(type: CriterionType): Boolean = when (type) {
        CriterionType.FOLDERS -> useFolderPriority && (preferredFolders.isNotEmpty() || demotedFolders.isNotEmpty())
        CriterionType.DATE -> datePreference != DatePreference.NONE
        CriterionType.SIZE -> sizePreference != SizePreference.NONE
        CriterionType.RESOLUTION -> preferHigherResolution
    }

    /** Redoslijed koji uvijek sadrži sve kriterije točno jednom (zaštita od oštećenih postavki). */
    fun normalizedOrder(): List<CriterionType> {
        val seen = LinkedHashSet<CriterionType>()
        order.forEach { seen.add(it) }
        CriterionType.entries.forEach { seen.add(it) }
        return seen.toList()
    }

    companion object {
        val DEFAULT_ORDER = listOf(CriterionType.FOLDERS, CriterionType.DATE, CriterionType.SIZE, CriterionType.RESOLUTION)
    }
}

/** Postavke koje utječu na skeniranje i grupiranje. */
data class ScanSettings(
    /** Najveća veličina datoteke u bajtovima; null = bez ograničenja. */
    val maxFileSizeBytes: Long? = 100L * MB,
    val categories: Set<FileCategory> = FileCategory.entries.toSet(),
    /** Traže li se i "slične" fotografije (zahtijevaju ručnu provjeru). */
    val findSimilarPhotos: Boolean = true,
    /** Prag sličnosti u postocima (75–98). Viši prag = strože. */
    val similarityPercent: Int = 85,
    /** Ograničenje paralelnih poslova (štedi bateriju i memoriju). */
    val parallelism: Int = 2,
    /** Ograničenje skeniranja na odabrane relativne mape (prazno = cijela dostupna pohrana). */
    val includedRelativeDirs: Set<String> = emptySet(),
    /** Vremenski interval nastanka datoteke (uključivo, milisekunde); null = bez granice. */
    val dateFrom: Long? = null,
    val dateTo: Long? = null,
    /** Kategorije na koje se vremenski interval primjenjuje; ostale se skeniraju bez obzira na datum. */
    val dateFilterCategories: Set<FileCategory> = FileCategory.entries.toSet()
) {
    val hasDateFilter: Boolean get() = dateFrom != null || dateTo != null

    /** Je li datum unutar intervala. Datoteka bez poznatog datuma ne prolazi aktivni filtar. */
    fun dateAccepted(category: FileCategory, millis: Long?): Boolean {
        if (!hasDateFilter || category !in dateFilterCategories) return true
        if (millis == null) return false
        if (dateFrom != null && millis < dateFrom) return false
        if (dateTo != null && millis > dateTo) return false
        return true
    }

    /** Najveća Hammingova udaljenost (od 64 bita) za "slične" fotografije. */
    val similarMaxDistance: Int
        get() = ((100 - similarityPercent.coerceIn(50, 99)) * 64 / 100).coerceAtLeast(VISUAL_MAX_DISTANCE + 1)

    companion object {
        const val MB = 1_000_000L
        /** Stroga granica za "vizualni duplikat" (≈ 90,6 % podudarnosti pHasha). */
        const val VISUAL_MAX_DISTANCE = 6
        /** Dodatna potvrda dHashom za vizualni duplikat. */
        const val VISUAL_MAX_DHASH_DISTANCE = 10
        /** Dopuštena razlika omjera stranica za vizualni duplikat (3 %). */
        const val VISUAL_ASPECT_TOLERANCE = 0.03
    }
}
