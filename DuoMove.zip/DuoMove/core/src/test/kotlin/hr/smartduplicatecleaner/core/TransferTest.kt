package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.transfer.IncomingFile
import hr.smartduplicatecleaner.core.transfer.PairingCode
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferClassifier
import hr.smartduplicatecleaner.core.transfer.TransferException
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.core.transfer.TransferReceiver
import hr.smartduplicatecleaner.core.transfer.TransferResult
import hr.smartduplicatecleaner.core.transfer.TransferSender
import hr.smartduplicatecleaner.core.transfer.TransferSink
import hr.smartduplicatecleaner.core.transfer.TransferSource
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Prijenos preko stvarnih TCP veza na lokalnom računalu (127.0.0.1). */
class TransferTest {
    private val code = "K7QM4XPA"

    private class MemorySink(var free: Long = Long.MAX_VALUE, val existing: Set<String> = emptySet()) : TransferSink {
        val files = ConcurrentHashMap<String, ByteArray>()
        val aborted = ConcurrentHashMap.newKeySet<String>()
        override fun freeBytes() = free
        override fun shouldSkip(item: TransferItem) = (item.relativeDir + item.name) in existing
        override fun create(item: TransferItem): IncomingFile {
            val key = item.relativeDir + item.name
            val bos = ByteArrayOutputStream()
            return object : IncomingFile {
                override val output: OutputStream = bos
                override fun commit() { files[key] = bos.toByteArray() }
                override fun abort() { aborted += key }
            }
        }
    }

    private class Recorder : TransferReceiver.Listener {
        val finished = CountDownLatch(1)
        val result = AtomicReference<TransferResult>()
        var started = ""
        override fun onSessionStarted(deviceName: String, files: Int, bytes: Long) { started = deviceName }
        override fun onSessionFinished(result: TransferResult) { this.result.set(result); finished.countDown() }
    }

    private fun data(i: Int, size: Int) = ByteArray(size) { ((it * 31 + i * 17) % 256).toByte() }

    private fun items(n: Int): Pair<List<TransferItem>, Map<Int, ByteArray>> {
        val rnd = java.util.Random(5)
        val list = mutableListOf<TransferItem>()
        val content = HashMap<Int, ByteArray>()
        for (i in 0 until n) {
            val size = when (i % 10) { 0 -> 3_000_000 + rnd.nextInt(500_000); 1 -> 0; else -> rnd.nextInt(200_000) }
            content[i] = data(i, size)
            list += TransferItem(i, if (i % 2 == 0) "DCIM/Camera/" else "Download/Docs/", "f$i.bin", size.toLong(), 1_700_000_000_000, null, TransferCategory.PHOTOS, null)
        }
        return list to content
    }

    private fun source(content: Map<Int, ByteArray>) = TransferSource { ByteArrayInputStream(content.getValue(it.id)) }

    @Test
    fun parallelTransfer_allFilesArriveIntact() {
        val (list, content) = items(120)
        val sink = MemorySink()
        val rec = Recorder()
        val receiver = TransferReceiver(code, sink, rec, port = 0)
        val port = receiver.start()
        try {
            val result = TransferSender("127.0.0.1", port, code, deviceName = "Stari mobitel", streams = 4).send(list, source(content))
            assertEquals(120, result.succeeded.size)
            assertTrue(result.failed.isEmpty())
            assertEquals(list.sumOf { it.size }, result.bytes)
            for (it in list) assertArrayEquals(content.getValue(it.id), sink.files.getValue(it.relativeDir + it.name))
            assertTrue(rec.finished.await(5, TimeUnit.SECONDS))
            assertEquals(120, rec.result.get().succeeded.size)
            assertEquals("Stari mobitel", rec.started)
        } finally { receiver.stop() }
    }

    @Test
    fun wrongCode_isRejected_andNothingWritten() {
        val sink = MemorySink()
        val receiver = TransferReceiver(code, sink, Recorder(), port = 0)
        val port = receiver.start()
        try {
            val (list, content) = items(3)
            TransferSender("127.0.0.1", port, "AAAA0000").send(list, source(content))
            fail("očekivano odbijanje")
        } catch (e: TransferException) {
            assertEquals(TransferException.Reason.AUTH_FAILED, e.reason)
            assertTrue(sink.files.isEmpty())
        } finally { receiver.stop() }
    }

    @Test
    fun skipExisting_noSpace_andSourceErrors() {
        val (list, content) = items(10)
        // Postojeća datoteka se preskače.
        val sink = MemorySink(existing = setOf("Download/Docs/f1.bin"))
        val rec = Recorder()
        val receiver = TransferReceiver(code, sink, rec, port = 0)
        val port = receiver.start()
        try {
            // Datoteka 3 se ne može pročitati do kraja (npr. izbrisana tijekom prijenosa).
            val broken = TransferSource { item ->
                val bytes = content.getValue(item.id)
                if (item.id != 3) ByteArrayInputStream(bytes) else object : InputStream() {
                    var pos = 0
                    override fun read(): Int = throw UnsupportedOperationException()
                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        if (pos > 1000) throw IOException("nestalo")
                        val n = minOf(len, 500); System.arraycopy(bytes, pos, b, off, n); pos += n; return n
                    }
                }
            }
            val r = TransferSender("127.0.0.1", port, code, streams = 2).send(list, broken)
            assertEquals(listOf(1), r.skipped.map { it.id })
            assertEquals(listOf(3), r.failed.map { it.first.id })
            assertEquals(8, r.succeeded.size)
            assertNull(sink.files["Download/Docs/f3.bin"])
            assertTrue("Download/Docs/f3.bin" in sink.aborted)
            assertTrue(rec.finished.await(5, TimeUnit.SECONDS))
        } finally { receiver.stop() }

        val small = MemorySink(free = 1000)
        val r2 = TransferReceiver(code, small, Recorder(), port = 0)
        val p2 = r2.start()
        try {
            TransferSender("127.0.0.1", p2, code).send(list, source(content))
            fail("očekivano: nema mjesta")
        } catch (e: TransferException) {
            assertEquals(TransferException.Reason.NO_SPACE, e.reason)
            assertEquals(1000L, e.freeBytes)
        } finally { r2.stop() }
    }

    @Test
    fun cancel_stopsTransfer_andReceiverDiscardsPartialFiles() {
        val list = (0 until 6).map { TransferItem(it, "", "big$it.bin", 20_000_000, null, null, TransferCategory.VIDEOS, null) }
        val sink = MemorySink()
        val rec = Recorder()
        val receiver = TransferReceiver(code, sink, rec, port = 0)
        val port = receiver.start()
        val cancelled = AtomicBoolean(false)
        try {
            val slow = TransferSource { object : InputStream() {
                override fun read(): Int = 1
                override fun read(b: ByteArray, off: Int, len: Int): Int { Thread.sleep(2); return minOf(len, 65536) }
            } }
            val r = TransferSender("127.0.0.1", port, code, streams = 2).send(list, slow, { cancelled.get() }) { p ->
                if (p.bytesDone > 3_000_000) cancelled.set(true)
            }
            assertTrue(r.cancelled)
            assertTrue(r.succeeded.size < list.size)
            assertTrue(rec.finished.await(10, TimeUnit.SECONDS))
            assertTrue(rec.result.get().cancelled)
            // Nijedna djelomična datoteka nije spremljena.
            assertTrue(sink.files.keys.all { k -> r.succeeded.any { it.name == k } })
        } finally { receiver.stop() }
    }

    @Test
    fun pairingCode_and_classifier() {
        val c = PairingCode.generate()
        assertEquals(8, c.length)
        assertEquals("K7QM4XPA", PairingCode.normalize(" k7qm-4xpa "))
        assertEquals("10000000", PairingCode.normalize("IO000000")) // I→1, O→0
        assertNull(PairingCode.normalize("K7QM-4XP"))
        assertEquals("K7QM-4XPA", PairingCode.display("K7QM4XPA"))
        val pass = PairingCode.passphrase("K7QM4XPA")
        assertTrue(pass.length in 8..63)
        assertTrue(PairingCode.NETWORK_NAME.startsWith("DIRECT-"))
        assertEquals(TransferCategory.APK_FILES, TransferClassifier.of(file("Download/igra.apk", 10)))
        assertEquals(TransferCategory.ARCHIVES, TransferClassifier.of(file("Download/a.rar", 10)))
        assertEquals(TransferCategory.PHOTOS, TransferClassifier.of(file("DCIM/a.jpg", 10)))
    }

    @Test
    fun maliciousPaths_areSanitized() {
        val sink = MemorySink()
        val rec = Recorder()
        val receiver = TransferReceiver(code, sink, rec, port = 0)
        val port = receiver.start()
        try {
            val evil = listOf(TransferItem(0, "../../etc/", "../passwd", 3, null, null, TransferCategory.OTHER, null))
            TransferSender("127.0.0.1", port, code).send(evil, TransferSource { ByteArrayInputStream(byteArrayOf(1, 2, 3)) })
            assertEquals(setOf("etc/.._passwd"), sink.files.keys)
        } finally { receiver.stop() }
    }
}
